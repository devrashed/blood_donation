<?php $__env->startSection('title', 'View All Founder Member'); ?>

<?php $__env->startSection('content'); ?>

 <div class="panel panel-default">
  <div class="panel-heading">View All Founder Member Information</div>
</div>

   <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name </th>
      <th scope="col">Designation</th>
      <th scope="col">Pic</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>

      <?php $__currentLoopData = $fumember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"></th>
      <td><?php echo e($member['faname']); ?></td>
      <td><?php echo e($member['designation']); ?></td>
      <td><img src='././public/upload/<?php echo e($member['fpicture']); ?>' width="140" height="100"></td>
      <td><a href="./editf/<?php echo e($member['id']); ?>"> Edit </a> / <a href="./delete/<?php echo e($member['id']); ?>">Delete</a> </td>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>