<!DOCTYPE html>
<html>
<head>

<link href="<?php echo e(asset('asset/admin/css/style.css')); ?>" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="<?php echo e(asset('asset/admin/css/bootstrap.min.css')); ?>">

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>

<script src="<?php echo e(asset('asset/admin/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('asset/admin/js/bootstrap.min.js')); ?>"></script>

<!-- Menu -->
<link href="<?php echo e(asset('asset/admin/css/ddsmoothmenu.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('asset/admin/css/ddsmoothmenu-v.css')); ?>" rel="stylesheet" type="text/css">

<script type="text/javascript" src="<?php echo e(asset('asset/admin/js/ddsmoothmenu.js')); ?>"></script>


<script type="text/javascript">
ddsmoothmenu.init({
	mainmenuid: "smoothmenu2", //Menu DIV id
	orientation: 'v', //Horizontal or vertical menu: Set to "h" or "v"
	classname: 'ddsmoothmenu-v', //class added to menu's outer DIV
	//customtheme: ["#804000", "#482400"],
	contentsource: "markup" //"markup" or ["container_id", "path_to_menu_file"]
})
</script>


<title><?php echo $__env->yieldContent('title'); ?></title>

</head>
<body>
<div id="wrapper">
  
 

<div class="header">  <?php echo $__env->make('layout.admin.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>


<div class="sidebar"> <?php echo $__env->make('layout.admin.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  </div>


<div class="content"> <?php echo $__env->yieldContent('content'); ?> </div> 


<div class="footer">  <?php echo $__env->make('layout.admin.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>  </div>


   

</div> <!-- END THE WRAPPER -->

</body>
</html>