<?php $__env->startSection('title', 'View ALL PhotoGallery'); ?>

<?php $__env->startSection('content'); ?>


<div class="panel panel-default">
  <div class="panel-heading">View All Founder Member Information</div>
</div>

   <table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Caption </th>
      <th scope="col">Pic</th>
      <th scope="col">Status</th>
    </tr>
  </thead>
  <tbody>

      <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"></th>
      <td><?php echo e($photo['photocaption']); ?></td>
      <td><?php echo e($photo['eventpic']); ?></td>
      <td></td>
      <td></td>
    </tr>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>

</table>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.admin.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>