<?php $__env->startSection('title', 'Home Page'); ?>
<?php $__env->startSection('content'); ?>


 <h2>This is my home page</h2>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>