<?php $__env->startSection('title', 'View ALL Donar'); ?>

<?php $__env->startSection('content'); ?>

<table class="table table-striped">
  <thead>
    <tr>
     
      <th scope="col">Fullname</th>
      <th scope="col">address</th>
      <th scope="col">Gender</th>
      <th scope="col">Blood Group</th>
      <th scope="col">Phone</th>
      <th scope="col">Distrcit</th>
      <th scope="col">Thana</th>
      <th scope="col">Status</th>
     

    </tr>
  </thead>
   <tbody>
    <!--  <?php echo e($donarview); ?> -->

    <?php $__currentLoopData = $donarview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $founddonars): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <tr>  
    
      <td><?php echo e($founddonars->fullname); ?></td>
       <td><?php echo e($founddonars->address); ?></td>
      <td><?php echo e($founddonars->gender); ?></td>
      <td><?php echo e($founddonars->bgroup); ?></td>
      <td><?php echo e($founddonars->phonenumber); ?>,  <?php echo e($founddonars->altePhone); ?></td>
      <td><?php echo e($founddonars->districName); ?></td>
      <td><?php echo e($founddonars->thana); ?></td>
      <th scope="col">

      <a href="./editf/<?php echo e($founddonars->mid); ?>">Edit</a> / 
      <a href="./delete/<?php echo e($founddonars->mid); ?>">Delete</a></th>
      
    </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody> 
 </table>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>