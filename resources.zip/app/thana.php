<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class thana extends Model
{
  protected $fillable = [
    'did',
    'thana',
    ];

  protected $table = 'thana';
}
