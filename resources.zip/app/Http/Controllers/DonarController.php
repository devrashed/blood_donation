<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Mdonar;
use App\district;
use App\thana;
use DB;

class DonarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function donarin()
    {
        
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
public function savedonar(Request $request)
 

    {        
       $request->validate([
        'fullname'=>'required',
        'address'=> 'required',
        'gender'=> 'required',
        'blgroup'=> 'required',
        'phonenumber'=> 'required',
        'alternetphone'=> 'required',
        'district'=> 'required',
        'thana'=> 'required',
        'status'=> 'required',
    ]);

    /*var_dump($request);
     exit(); */

      $data = new Mdonar([
        'fullname' => $request->get('fullname'),
        'address'=> $request->get('address'),
        'gender'=> $request->get('gender'),
        'bgroup'=> $request->get('blgroup'),
        'phonenumber'=> $request->get('phonenumber'),
        'altePhone'=> $request->get('alternetphone'),
        'district'=> $request->get('district'),
        'thanaid'=> $request->get('thana'),
        'status'=> $request->get('status'),
      ]);
         
    /* var_dump($data);
     exit();*/

      $data->save();
      //return redirect()->back();
      return redirect('/createdoner')->with('success', 'New Donar Info has been added');
    }


public function forntstore(Request $request)
    {

       $request->validate([
        'fullname'=>'required',
        'address'=> 'required',
        'gender'=> 'required',
        'blgroup'=> 'required',
        'phonenumber'=> 'required',
        'alternetphone'=> 'required',
        'district'=> 'required',
        'thanas'=> 'required',
        'status'=> 'required',
    ]);
  /*  var_dump($request);
     exit();*/

     $data = new Mdonar([
    'fullname' => $request->get('fullname'),
    'address'=> $request->get('address'),
    'gender'=> $request->get('gender'),
    'bgroup'=> $request->get('blgroup'),
    'phonenumber'=> $request->get('phonenumber'),
    'altePhone'=> $request->get('alternetphone'),
    'district'=> $request->get('district'),
    'thanaid'=> $request->get('thanas'),
    'status'=> $request->get('status'),
      ]);
         
    /*var_dump($data);
    die();*/
     /*dd($data); 
     die();  */

      $data->save();
      return redirect('/donarjoin')->with('success', 'New Donar Info has been added');
    }



   public function donarviw() 
     {
       //$donarfound = Mdonar::paginate(20); //all()->toArray();
       
       $donarfound = DB::table('mdonar')
                ->leftJoin('district', 'mdonar.district', '=', 'district.id') 
                ->leftJoin('thana', 'mdonar.thanaid', '=', 'thana.tid')
                /*->select('mdonar.*')   */
                ->get(); 
       
     /*  dd($donarfound);
    die();*/

     //return view ('layout.admin.viewdonar',compact('donarfound'));   
    //return view('layout.admin.viewdonar', array ( 'donarfound' => $donarfound ));
    return view('layout.admin.viewdonar')->with('donarview',$donarfound);
     }


  public function donarDel($id) {

       $ddd=DB::table('mdonar')->where('mid',$id)->delete();
       return redirect('/viewdonar')->with('success','Post removed'); 
    }




    public function seldistrict() 
     {
       $dis = district::all()->toArray();
       return view ('layout.admin.createdonar',compact('dis')); 
       return view ('layout.donarjoin',compact('dis')); 
     }

    
    public function showdistrict() 
     {
       $dis = district::all()->toArray();
       return view ('layout.donarjoin',compact('dis')); 
     }



     public function viewdisThana()
    {
        $dis=district::all();
        $thana=thana::all();
        return view('layout.admin.createdonar')->withDis($dis)->withThana($thana);
        // return view('layout.admin.donarcreate')->withDis($dis)->withThana($thana);
    }

    public function donarsearch()
    {
       $dis=district::all();
       return view('layout.admin.donarsearch')->withDis($dis);
    }
  

  public function donarfind(Request $request){
     
     
    $district=$request->get('district');
    $thana=$request->get('thana');
    $blgroup=$request->get('blgroup');
   
    /*$check= $blgroup.$thana.$district;

    dd($check);
    die();*/

    $donarinfo = DB::table('mdonar')
                ->leftJoin('district', 'mdonar.district', '=', 'district.id') 
                ->leftJoin('thana', 'mdonar.thanaid', '=', 'thana.tid')   
                ->where([
                    ['district', '=', $district],
                    ['thanaid', '=', $thana],
                    ['bgroup', '=', $blgroup]
                ])->get();
        
      //var_dump($donarinfo);          
      //print_r($donarinfo);  
     /*  dd($donarinfo);
      die();*/
     
      return view('layout.admin.donarfind')->with('donars',$donarinfo);
       //return view ('layout.admin.donarsearch')->with('donars',$donarinfo);
  }
        


    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function donarrequest () {          
         
       $donarrequest = DB::table('mdonar')
                    ->where('status', '=', 0)
                    ->get(); 
       
        /*dd ($donarrequest);   
        die();*/

       return view('layout.admin.donaRequest',compact('donarrequest'));

/*    $fumember = Mfounder::paginate(20);
    return view ('layout.admin.viewFounder',compact('fumember')); */  
      

    }

    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
