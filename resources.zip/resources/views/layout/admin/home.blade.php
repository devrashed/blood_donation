@extends('layout.admin.default')
@section('title', 'Home Page')
@section('content')


 <h2>This is my home page</h2>



@endsection
