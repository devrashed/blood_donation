@extends('layout.admin.default')
@section('title', 'View ALL Donar')

@section('content')

<table class="table table-striped">
  <thead>
    <tr>
     
      <th scope="col">Fullname</th>
      <th scope="col">address</th>
      <th scope="col">Gender</th>
      <th scope="col">Blood Group</th>
      <th scope="col">Phone</th>
      <th scope="col">Distrcit</th>
      <th scope="col">Thana</th>
      <th scope="col">Status</th>
     

    </tr>
  </thead>
   <tbody>
    <!--  {{$donarview}} -->

    @foreach($donarview as $founddonars) 
    <tr>  
    
      <td>{{$founddonars->fullname}}</td>
       <td>{{$founddonars->address}}</td>
      <td>{{$founddonars->gender}}</td>
      <td>{{$founddonars->bgroup}}</td>
      <td>{{$founddonars->phonenumber}},  {{$founddonars->altePhone}}</td>
      <td>{{$founddonars->districName}}</td>
      <td>{{$founddonars->thana}}</td>
      <th scope="col">

      <a href="./editf/{{$founddonars->mid}}">Edit</a> / 
      <a href="./delete/{{$founddonars->mid}}">Delete</a></th>
      
    </tr> 
    @endforeach
   </tbody> 
 </table>
 
@endsection
