@extends('layout.admin.default')
@section('title', 'View ALL Donar')

@section('content')

<table class="table table-striped">
  <thead>
    <tr>
     
      <th scope="col">Fullname</th>
      <th scope="col">Address</th>
      <th scope="col">Gender</th>
      <th scope="col">Blood Group</th>
      <th scope="col">Last Donate Date</th>
      <th scope="col">Phone</th>
      <th scope="col">Distrcit</th>
      <th scope="col">Thana</th>
      <th scope="col">Status</th>
     

    </tr>
  </thead>
   <tbody>
     <!-- {{$donarfound}} -->

    @foreach($donarfound as $donarview) 
    <tr>  
    
      <td>{{$donarview->fullname}}</td>
      <td>{{$donarview->address}}</td>
      <td>{{$donarview->gender}}</td>
      <td>{{$donarview->bgroup}}</td>
      <td>{{$donarview->lastdate}}</td>
      <td>{{$donarview->phonenumber}},  {{$donarview->altePhone}}</td>
      <td>{{$donarview->districName}}</td>
      <td>{{$donarview->thana}}</td>
      <th scope="col">

      <a href="./doEdit/{{$donarview->mid}}">Edit</a> / 
      <a href="./delete/{{$donarview->mid}}">Delete</a></th>
      
    </tr> 
    @endforeach
   </tbody> 
 </table>
 
@endsection
