@extends('layout.admin.default')
@section('title', 'Find Your Donar')

@section('content')


@foreach($donars as $donarinfo)

<strong>District :</strong> {{$donarinfo->districName}}

<strong>Thana :</strong> {{$donarinfo->thana}} 

<strong>Blood Group :</strong> {{$donarinfo->bgroup}} 

@endforeach 

</br></br></br>
<table class="table table-bordered">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Name</th>
      <th scope="col">Gender</th>
      <th scope="col">Address</th>
      <th scope="col">Phone </th>
      <th scope="col">Alternate Phone </th>
    </tr>
  </thead>



@foreach($donars as $donarinfo)

  <tbody>
    <tr>
      <th scope="row">1</th>
      <td>{{$donarinfo->fullname}}</td>
      <td>{{$donarinfo->gender}}</td>
      <td>{{$donarinfo->address}}</td>
      <td>{{$donarinfo->phonenumber}}</td>
      <td>{{$donarinfo->altePhone}}</td>
    </tr>

  </tbody>


@endforeach 

</table>






   



@endsection