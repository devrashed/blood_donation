@extends('layout.admin.default')
@section('title', 'View ALL Donar')

@section('content')


<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading"> Find you Donar </div>

      <div class="panel-body">
 <form class="form-horizontal"  action="{{URL::to('/donarFind')}}" method="get">
                                

<div class="form-group">
    <label for="email" class="col-md-4 control-label">Select District Name</label>     
    <div class="col-md-6">       
       <select class="custom-select mr-sm-2" id="district" name="district">
       <option selected>Select District Name</option>

		@foreach($dis as $districts)
		<option value="{{$districts['id']}}">{{$districts['districName']}}</option>
		@endforeach 

      </select>
    </div>
</div>

<div class="form-group">
    <label for="email" class="col-md-4 control-label">Select Thana Name</label>     
    <div class="col-md-6">       
       <select class="custom-select mr-sm-2" id="thana" name="thana">
        <option selected>Select Thana Name</option>

 
    </select>
    </div>
</div>


 <div class="form-group">
    <label for="email" class="col-md-4 control-label">Blood Group</label>     
    <div class="col-md-6">       
       <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="blgroup">
        <option selected>--Blood Group--</option>
        <option value="A+">A+</option>
        <option value="A-">A-</option>
        <option value="B+">B+</option>
        <option value="B-">B-</option>
        <option value="O+">O+</option>
        <option value="O-">O-</option>
        <option value="AB+">AB+</option>      
        <option value="AB-">AB-</option>
    </select>
    </div>
</div>

            <div class="form-group">
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary">
                        Search
                    </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

  

 <script type="text/javascript">
     
     $('#district').on('change',function(e){

       var district_id = e.target.value;  
       console.log(district_id);

       $.get('/blood/ajax-cat/' + district_id, function(data){            
             console.log(data);

            $('#thana').empty(); 
            $.each(data, function(createdoner, subcatObj){              
    $('#thana').append('<option value="'+subcatObj.tid+'">'+subcatObj.thana+'<option>')

            } )
         })
     });

 </script>
 
 

@endsection