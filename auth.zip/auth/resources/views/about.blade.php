@extends('layouts.app')
@section('title', 'Welcome to About Page')
@section('content')

      
                  <h1> About Us </h1>



@endsection