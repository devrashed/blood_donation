@extends('layouts.app')
@section('title', 'Welcome to Service Page')
@section('content')


      
                  <h1> Service Page </h1>



@endsection