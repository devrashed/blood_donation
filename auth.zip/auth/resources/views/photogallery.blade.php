@extends('layouts.app')
@section('title', 'Photogallery of Care life Bangladesh')

@section('content')






@endsection