<?php $__env->startSection('title', 'View ALL Donar'); ?>

<?php $__env->startSection('content'); ?>

<table class="table table-striped">
  <thead>
    <tr>
     
      <th scope="col">Fullname</th>
      <th scope="col">Address</th>
      <th scope="col">Gender</th>
      <th scope="col">Blood Group</th>
      <th scope="col">Last Donate Date</th>
      <th scope="col">Phone</th>
      <th scope="col">Distrcit</th>
      <th scope="col">Thana</th>
      <th scope="col">Status</th>
     

    </tr>
  </thead>
   <tbody>
     <!-- <?php echo e($donarfound); ?> -->

    <?php $__currentLoopData = $donarfound; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donarview): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    <tr>  
    
      <td><?php echo e($donarview->fullname); ?></td>
      <td><?php echo e($donarview->address); ?></td>
      <td><?php echo e($donarview->gender); ?></td>
      <td><?php echo e($donarview->bgroup); ?></td>
      <td><?php echo e($donarview->lastdate); ?></td>
      <td><?php echo e($donarview->phonenumber); ?>,  <?php echo e($donarview->altePhone); ?></td>
      <td><?php echo e($donarview->districName); ?></td>
      <td><?php echo e($donarview->thana); ?></td>
      <th scope="col">

      <a href="./doEdit/<?php echo e($donarview->mid); ?>">Edit</a> / 
      <a href="./delete/<?php echo e($donarview->mid); ?>">Delete</a></th>
      
    </tr> 
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody> 
 </table>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>