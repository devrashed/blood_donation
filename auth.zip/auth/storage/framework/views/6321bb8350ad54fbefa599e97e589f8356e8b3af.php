<div id="smoothmenu2" class="ddsmoothmenu-v">
<ul>

	<li><a href="#">Home</a></li>
	<li><a href="#">Founder Member</a>
   <ul>
            <li><a href="<?php echo url('/createfounder');; ?>">Add New Member</a></li>
            <li><a href="<?php echo url('/viewFounder');; ?>">View Member</a></li> 
   </ul> 

	</li>
	<li><a href="#">Photogallery</a>
       
  <ul>
    <li><a href="<?php echo url('/createphoto');; ?>">Add New Photo</a></li>
    <li><a href="<?php echo url('/viewphoto');; ?>">View All Photo</a></li> 
  </ul> 

	</li>

    <li><a href="#">Donar List</a>

  <ul>
    <li><a href="<?php echo url('/createdoner');; ?>">Add New Donar</a></li>
    <li><a href="<?php echo url('/viewdonar');; ?>">View All Donar</a></li> 
    <li><a href="<?php echo url('/donarequest');; ?>">New Donar Request</a></li> 
  </ul>


    </li>

    <li><a href="<?php echo url('/donarsearch');; ?>">Donar Search</a></li>
    
    <li><a href="#">User Information</a>
          
       <ul>
          <li><a href="<?php echo url('/createuser');; ?>">Create New User</a></li>
          <li><a href="<?php echo url('/viewuser');; ?>">Show All User</a></li>
       </ul> 

    </li>    

    <li><a href="<?php echo url('/changepassword');; ?>">Change Password</a></li>    


</ul>


</div>
