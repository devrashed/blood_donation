<?php $__env->startSection('title', 'Create the Donar List'); ?>
<?php $__env->startSection('content'); ?>


<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Add New Donar Information</div>
    
    <?php if(session()->get('success')): ?>
    <div class="alert alert-success">
    <?php echo e(session()->get('success')); ?>  
    </div><br />
    <?php endif; ?>

 <div class="panel-body">
 
   <form  action="<?php echo e(url('Doupdate', [$data->mid])); ?>" method="post">
                          <?php echo e(csrf_field()); ?>

                                
<div class="form-group">
    <label for="fullname" class="col-md-4 control-label">Full Name</label>

    <div class="col-md-6">
<input id="fullname" type="text" class="form-control" name="fullname" value="<?php echo e($data->fullname); ?>">                        
    </div>
</div>

<div class="form-group">
    <label for="address" class="col-md-4 control-label">Address</label>
    <div class="col-md-6">
<input id="address" type="text" class="form-control" name="address" value="<?php echo e($data->address); ?>">
    </div>
</div>

<div class="form-group">
    <label for="email" class="col-md-4 control-label">Gender</label>     
    <div class="col-md-6">       
       <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="gender">
        <option selected value="<?php echo e($data->gender); ?>"><?php echo e($data->gender); ?></option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
    </select>
    </div>
</div>

 <div class="form-group">
    <label for="email" class="col-md-4 control-label">Blood Group</label>     
    <div class="col-md-6">       
       <select class="custom-select mr-sm-2" id="inlineFormCustomSelect" name="bgroup">
        <option selected value="<?php echo e($data->bgroup); ?>"><?php echo e($data->bgroup); ?></option>
        <option value="A+">A+</option>
        <option value="B+">B+</option>
        <option value="O+">O+</option>
        <option value="O-">O-</option>
        <option value="AB+">AB+</option>
        <option value="A-">A-</option>
        <option value="B-">B-</option>
        <option value="AB-">AB-</option>
    </select>
    </div>
</div>


<div class="form-group">
    <label for="password" class="col-md-4 control-label">Phone Number</label>
 <div class="col-md-6">
    <input id="text" type="text" class="form-control" name="phonenumber" 
    value="<?php echo e($data->phonenumber); ?>">
  </div>
</div>

<div class="form-group">
    <label for="password-confirm" class="col-md-4 control-label">Alternate Phone Number</label>
    <div class="col-md-6">
<input id="phonenumber" type="text" class="form-control" name="altePhone" value="<?php echo e($data->altePhone); ?>">
    </div>
</div>

<div class="form-group">
    <label for="email" class="col-md-4 control-label">Select District Name</label>     
    <div class="col-md-6">       
       <select class="custom-select mr-sm-2" id="district" name="district">
    <option selected value="<?php echo e($data->district); ?>"><?php echo e($data->districName); ?></option>
    <?php $__currentLoopData = $dis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
    <option value="<?php echo e($dis['id']); ?>"> <?php echo e($dis['districName']); ?></option>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
      
    </select>
    </div>
</div>

<div class="form-group">
    <label for="thana" class="col-md-4 control-label">Select Thana Name</label>     
    <div class="col-md-6">       
       <select class="custom-select mr-sm-2" id="thana" name="thanaid">
           <option selected value="<?php echo e($data->thanaid); ?>"><?php echo e($data->thana); ?></option>
 
    </select>
    </div>
</div>

<div class="form-group">
 <div class="col-md-6">       
       <input id="address" type="hidden" class="form-control" name="status" value="1">
    </div>
</div>

<div class="form-group">
    <label for="thana" class="col-md-4 control-label">Last Date of Donet Blood</label>     
    <div class="col-md-6">       
    <input id="phonenumber" type="Date" class="form-control" name="lastdate" value="<?php echo e($data->lastdate); ?>">
    </div>
</div>

 <div class="form-group">
                <div class="col-md-6">
                    <button type="submit" class="btn btn-primary">
                        Submit
                    </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

 <script type="text/javascript">
     
     $('#district').on('change',function(e){

       var district_id = e.target.value;  

       var url =  '<?php echo URL::to('ajax-subcat'); ?>/';

       $.get(url + district_id, function(data){
            
             console.log(data);

    $('#thana').empty(); 
    $.each(data, function(createdoner, subcatObj){       
               $('#thana').append('<option value="'+subcatObj.tid+'">'+subcatObj.thana+'</option>');

            } );

            

    $('#thana');
         })
     });

 </script>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.admin.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>